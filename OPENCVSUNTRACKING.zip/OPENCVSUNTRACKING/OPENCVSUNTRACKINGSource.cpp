//Preliminary Sun Tracking code
//Code by Ryan Lei
//As of May 24, 2017: Code can identify when the "sun" is within boundaries.
//Now, see if you can do the same thing with the Raspberry Pi.

#include <iostream>
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"

using namespace cv;
using namespace std;

int main() {	//Do I need (int argc, char**) argv??
	VideoCapture cap(0);	//MAKE THIS "0" IF YOU ARE USING THE LOGITECH CAMERA!!! IF SCREEN TURNS BLACK, PLAY AROUN WITH NUMBERS, SOMETIMES DEFAULT CHANGES.

	if (!cap.isOpened()) {
		cout << "Cannot open webcam" << endl;
		return -1;
	}

	namedWindow("Edited", CV_WINDOW_AUTOSIZE);
	namedWindow("Original", CV_WINDOW_AUTOSIZE);

	//HSV Values for reading in Sunlight:
	int iLowH = 0;
	int iHighH = 20;
	int iLowS = 0;
	int iHighS = 255;
	int iLowV = 238;
	int iHighV = 255;
	char checkEscKey = 0;
	//Matric headers 
	Mat imgHSV;			//HSV image
	Mat imgEdited;		//Edited Image
	Mat imgOriginal;	//Input Image
	vector <Vec3f> v3fCircles;	// 3 element vector of floats, this will be the pass by reference output of HoughCircles()

	while (checkEscKey != 27 && cap.isOpened()) {
		bool bSuccess = cap.read(imgOriginal);	//Read new frame from camera
		if (!bSuccess) break;					//If no new frame read from camera, then stop and close out

		cvtColor(imgOriginal, imgHSV, COLOR_BGR2HSV);	//Convert from BGR to HSV
		inRange(imgHSV, Scalar(iLowH, iLowS, iLowV), Scalar(iHighH, iHighS, iHighV), imgEdited);	//Threshold for our image. We might only need the upper threshold.
		Mat structuringElement = getStructuringElement(MORPH_RECT, Size(3, 3));

		////morphological opening (remove small objects from the foreground)
		erode(imgEdited, imgEdited, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));
		dilate(imgEdited, imgEdited, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));

		////morphological closing (fill small holes in the foreground)
		dilate(imgEdited, imgEdited, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));
		erode(imgEdited, imgEdited, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)));

		//FINDS CIRCLE IN EDITED IMAGE:
		HoughCircles(imgEdited,			// input image
			v3fCircles,							// function output (must be a standard template library vector
			CV_HOUGH_GRADIENT,					// two-pass algorithm for detecting circles, this is the only choice available
			2,									// size of image / this value = "accumulator resolution", i.e. accum res = size of image / 2
			imgEdited.rows / 4,				// min distance in pixels between the centers of the detected circles
			100,								// high threshold of Canny edge detector (called by cvHoughCircles)						
			50,									// low threshold of Canny edge detector (set at 1/2 previous value)
			10,									// min circle radius (any circles with smaller radius will not be returned)
			500);								// max circle radius (any circles with larger radius will not be returned)

		//Draw vertical rectangle somewhere in the frame:
		rectangle(imgOriginal,												// draw on original image
			Point(215, 0),																//Point 1
			Point(425, 480),																//Point 2
			Scalar(0, 0, 0),													//Color of rectangle
			1,																		//Thickness
			8,																		//Type of Line
			0);																		//Shift in bits
		//Draw horizontal rectangle somewhere in the frame:
		rectangle(imgOriginal,												// draw on original image
			Point(0, 160),																//Point 1
			Point(640, 320),																//Point 2
			Scalar(0, 0, 0),													//Color of rectangle
			1,																		//Thickness
			8,																		//Type of Line
			0);

		//BORROWED FROM OTHER CODE
		for (int i = 0; i < v3fCircles.size(); i++) {		// for each circle . . .
															// show ball position x, y, and radius to command line
			cout << "Sun's position: x = " << v3fCircles[i][0]			// x position of center point of circle
				<< ", y = " << v3fCircles[i][1]								// y position of center point of circle
				<< ", radius = " << v3fCircles[i][2] << "\n";				// radius of circle

			// draw small green circle at center of detected object
			circle(imgOriginal,												// draw on original image
				Point((int)v3fCircles[i][0], (int)v3fCircles[i][1]),		// center point of circle
				3,																// radius of circle in pixels
				Scalar(0, 0, 0),											// draw pure green (remember, its BGR, not RGB)
				CV_FILLED);														// thickness, fill in the circle

			//PUT TEXT NEXT TO INDICATED POINT:
			putText(imgOriginal,											// draw on original image
				"BRIGHT THING",															//Text displayed
				Point((int)v3fCircles[i][0], (int)v3fCircles[i][1]),		//Bottom left corner point of text
				CV_FONT_HERSHEY_PLAIN,											//Font type
				1,																//Font Scale
				Scalar(0, 0, 0),											//Text Color
				1,																//Text thickness
				8,																//Line type
				false);															//Image data origin. False: top left corner. True: bottom left corner

			// DRAW CIRCLE AROUND DETECTED OBJECT																	
			circle(imgOriginal,											// draw on original image
				Point((int)v3fCircles[i][0], (int)v3fCircles[i][1]),		// center point of circle
				(int)v3fCircles[i][2],										// radius of circle in pixels
				Scalar(255, 255, 255),											//Circle Color (remember, its BGR, not RGB)
				2);															// thickness of circle in pixels
			
			//TELL USER IF THE BRIGHT SPOT IS WITHIN BOUNDARIES. THIS IS A CRITICAL IF STATEMENT
			if (215 < (v3fCircles[i][0] - v3fCircles[i][2]) && (v3fCircles[i][0] + v3fCircles[i][2]) < 425 && 160 < (v3fCircles[i][1] - v3fCircles[i][2]) && (v3fCircles[i][1] + v3fCircles[i][2]) < 320) {
				cout << "ON TARGET" << endl;								//Boundaries:  X-axis: 215, 425 Y-axis: 160, 320
				}

			//TO BE MORE SPECIFICALLY, WE WANT TO TELL PI WHERE THE SUN IS:
			//On the left:
			if (v3fCircles[i][0] < 215) {
				if(v3fCircles[i][1] < 160) cout << "TOP ";
				if(v3fCircles[i][1] > 320) cout << "BOTTOM ";
				cout << "LEFT" << endl;
			}
			//On the right:
			if (v3fCircles[i][0] > 425) {
				if (v3fCircles[i][1] < 160) cout << "TOP ";
				if (v3fCircles[i][1] > 320) cout << "BOTTOM ";
				cout << "RIGHT" << endl;
			}
			//In the center:
			if (v3fCircles[i][0] < 425 && v3fCircles[i][0] > 215) {
				if (v3fCircles[i][1] < 160) cout << "TOP ";
				if (v3fCircles[i][1] > 320) cout << "BOTTOM ";
				if (v3fCircles[i][1] < 160 || v3fCircles[i][1] > 320) cout << "CENTER" << endl;	//Make this last statement so we have a special text for the snu being in the center.
			}

			//IN RASPBERRY PI CODE, THIS IS WHERE YOU MOVE THE ACTUATOR LEFT/RIGHT AND UP/DOWN.

			}	// end for
		
		imshow("Edited", imgEdited);					//Display Edited Image
		imshow("Original", imgOriginal);				//Display Original Image

		checkEscKey = waitKey(1);	//Delay (ms) and get a key press if there is any.
	}	//End while loop
	return 0;
}

